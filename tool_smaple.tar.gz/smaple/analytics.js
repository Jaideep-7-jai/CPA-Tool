document.addEventListener('DOMContentLoaded', async () => {
  try {
    const res = await fetch('/api/analytics');
    const analyticsData = await res.json();

    // Update metric cards
    document.getElementById('totalRequests').textContent = analyticsData.total_requests || 0;
    document.getElementById('completedCount').textContent = analyticsData.completed || 0;
    document.getElementById('failedCount').textContent = analyticsData.failed || 0;
    document.getElementById('avgTime').textContent = (analyticsData.avg_execution_time_sec || 0) + 's';

    const total = analyticsData.total_requests || 1;
    const completedPercent = Math.round((analyticsData.completed || 0) / total * 100) + '%';
    const failedPercent = Math.round((analyticsData.failed || 0) / total * 100) + '%';
    document.getElementById('completedPercent').textContent = completedPercent;
    document.getElementById('failedPercent').textContent = failedPercent;

    // Update recent requests table
    const tbody = document.getElementById('recentRequestsBody');
    if (analyticsData.recent_requests && analyticsData.recent_requests.length > 0) {
      tbody.innerHTML = analyticsData.recent_requests.map(req => `
        <tr>
          <td><span class="badge-criteria">${req.criteria.toUpperCase()}</span></td>
          <td><span class="badge ${req.status}">${req.status}</span></td>
          <td>${req.created_at}</td>
          <td><code>${req.request_uuid.substring(0, 12)}...</code></td>
        </tr>
      `).join('');
    } else {
      tbody.innerHTML = '<tr><td colspan="4" class="text-center">No requests yet</td></tr>';
    }

    // Pie Chart - Requests by Type
    const typeCtx = document.getElementById('requestsTypeChart');
    if (typeCtx) {
      const typeData = analyticsData.by_criteria || {};
      const typeLabels = Object.keys(typeData).map(k => k.toUpperCase());
      const typeValues = Object.keys(typeData).map(k => typeData[k].total);
      const typeColors = ['#FF6384', '#36A2EB', '#FFCE56'];

      new Chart(typeCtx.getContext('2d'), {
        type: 'pie',
        data: {
          labels: typeLabels,
          datasets: [{
            data: typeValues,
            backgroundColor: typeColors,
            borderColor: '#fff',
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'bottom'
            }
          }
        }
      });
    }

    // Bar Chart - Success vs Failure by Type
    const sfCtx = document.getElementById('successFailureChart');
    if (sfCtx) {
      const typeData = analyticsData.by_criteria || {};
      const sfLabels = Object.keys(typeData).map(k => k.toUpperCase());
      const completedData = Object.keys(typeData).map(k => typeData[k].completed);
      const failedData = Object.keys(typeData).map(k => typeData[k].failed);

      new Chart(sfCtx.getContext('2d'), {
        type: 'bar',
        data: {
          labels: sfLabels,
          datasets: [
            {
              label: 'Completed',
              data: completedData,
              backgroundColor: '#4CAF50',
              borderColor: '#388E3C',
              borderWidth: 1
            },
            {
              label: 'Failed',
              data: failedData,
              backgroundColor: '#F44336',
              borderColor: '#C62828',
              borderWidth: 1
            }
          ]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'bottom'
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                stepSize: 1
              }
            }
          }
        }
      });
    }
  } catch (err) {
    console.error('Error loading analytics:', err);
    document.getElementById('recentRequestsBody').innerHTML =
      '<tr><td colspan="4" class="text-center">Error loading analytics</td></tr>';
  }
});
