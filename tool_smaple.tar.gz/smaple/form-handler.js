const form = document.getElementById('requestForm');
const formMessage = document.getElementById('formMessage');

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    formMessage.textContent = 'Submitting...';
    formMessage.className = 'message loading';

    const body = new FormData(form);
    try {
      const res = await fetch('/api/submit', { method: 'POST', body });
      const data = await res.json();

      if (!res.ok) {
        formMessage.textContent = data.error || 'Submission failed';
        formMessage.className = 'message error';
        return;
      }

      form.reset();
      formMessage.textContent = `✅ Request submitted successfully: ${data.request_uuid.substring(0, 12)}...`;
      formMessage.className = 'message success';

      // Reload page after 2 seconds to show updated history
      setTimeout(() => {
        location.reload();
      }, 2000);
    } catch (err) {
      formMessage.textContent = `Error: ${err.message}`;
      formMessage.className = 'message error';
    }
  });
}
